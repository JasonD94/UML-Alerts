package uml_alerts.uml_alerts;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;


public class About extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);
    }
}
