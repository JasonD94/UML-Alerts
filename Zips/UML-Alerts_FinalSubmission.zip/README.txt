README file for UML-Alerts
Created by Jason Downing and Udit Bhansali

About.java
Created by Jason / Udit
Displays the “about.xml” layout, which lists the authors of the app.

GPSTracker.java
Created by Jason / Udit
Contains the  GPS Tracker service.

GoogleMaps.java
Created by Jason / Udit
Shows the Google Maps view where we display all previously sent alerts.

MainActivity.java
Created by Jason / Udit
The main screen of the app. Shows Alerts, Contacts and Previous Alerts, depending on what view has been selected.

NavigationDrawFragment.java
Created by Jason / Udit
Class for the Navigation bar, shows up on the left hand side of the screen when you slide left or press the menu bar.
